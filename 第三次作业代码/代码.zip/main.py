from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from preprocess import cross_val_model, laplace_smoothing_NB

# 线性判别
lda = LinearDiscriminantAnalysis()
# Logistic
lr = LogisticRegression()
# KNN
k = 9  # 设置 k 值为 9（最佳）
knn = KNeighborsClassifier(n_neighbors=k)
# 先验分布是高斯分布的朴素贝叶斯
nb = GaussianNB()

"""
直接测试：
Accuracy: 0.9571428571428572
Accuracy: 0.9571428571428572
Accuracy: 0.9714285714285714
Accuracy: 0.9642857142857143
"""
# val_model(lda)
# val_model(lr)
# val_model(knn)
# val_model(nb)

"""
五折交叉验证：
Average accuracy: 0.9570606372045221
Average accuracy: 0.9613669064748201
Average accuracy: 0.964213771839671
Average accuracy: 0.959917780061665
"""
cross_val_model(lda)
cross_val_model(lr)
cross_val_model(knn)
cross_val_model(nb)

# 拉普拉斯平滑后的朴素贝叶斯
laplace_smoothing_NB()  # Best alpha: 0.01  Best accuracy: 0.9071428571428571

# 先验分布为多项式分布
nb2 = MultinomialNB()
cross_val_model(nb2)  # Average accuracy: 0.8884069886947584
